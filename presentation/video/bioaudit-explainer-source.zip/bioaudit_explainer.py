#!/usr/bin/env python3
"""Render Bio-Audit narrated explainer motion graphics to H.264 via FFmpeg.

Inputs: generated voice-over WAV, instrumental MP3, and word-timed transcription JSON.
The animation uses only local vector/Pillow drawing; no repository code is executed.
"""
from __future__ import annotations
import json, math, os, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1280, 720, 24
DURATION = 94.0
BASE = Path(__file__).resolve().parent
VOICE = BASE / 'bioaudit-explainer-voiceover.wav'
MUSIC = BASE / 'bioaudit-explainer-music.mp3'
TRANSCRIPT = BASE / 'bioaudit-explainer-transcription.json'
OUTPUT = BASE / 'bioaudit-explainer.mp4'
SRT = BASE / 'bioaudit-explainer-captions.srt'

C = {
    'paper': '#F6F2E9', 'ink': '#172329', 'muted': '#627069', 'line': '#D7D8CA',
    'white': '#FFFEFA', 'lime': '#C7E34B', 'mint': '#59D7BE', 'coral': '#FF8065',
    'violet': '#9787FF', 'blue': '#6E8CFF', 'dark2': '#28343B', 'palegreen': '#EFF5D8',
    'palecoral': '#FFF0E8', 'gray': '#A8B0A7', 'green': '#3D6C35',
}
FONTDIR='/usr/share/fonts/truetype/dejavu'
FONT={
  'regular': ImageFont.truetype(FONTDIR+'/DejaVuSans.ttf', 20),
  'small': ImageFont.truetype(FONTDIR+'/DejaVuSans.ttf', 14),
  'tiny': ImageFont.truetype(FONTDIR+'/DejaVuSans.ttf', 11),
  'body': ImageFont.truetype(FONTDIR+'/DejaVuSans.ttf', 23),
  'bodybold': ImageFont.truetype(FONTDIR+'/DejaVuSans-Bold.ttf', 23),
  'h1': ImageFont.truetype(FONTDIR+'/DejaVuSans-Bold.ttf', 47),
  'h2': ImageFont.truetype(FONTDIR+'/DejaVuSans-Bold.ttf', 34),
  'h3': ImageFont.truetype(FONTDIR+'/DejaVuSans-Bold.ttf', 25),
  'mono': ImageFont.truetype(FONTDIR+'/DejaVuSansMono.ttf', 17),
  'monobold': ImageFont.truetype(FONTDIR+'/DejaVuSansMono-Bold.ttf', 17),
  'monosmall': ImageFont.truetype(FONTDIR+'/DejaVuSansMono.ttf', 13),
  'serif': ImageFont.truetype(FONTDIR+'/DejaVuSerif.ttf', 24),
  'caption': ImageFont.truetype(FONTDIR+'/DejaVuSans.ttf', 18),
}

SCENES=[
 (0.0, 9.74, '01 · THE CHALLENGE'),
 (9.74, 22.04, '02 · SIMPLE INPUTS'),
 (22.04, 36.40, '03 · CLAIMS & CODE'),
 (36.40, 52.64, '04 · EVIDENCE MATCH'),
 (52.64, 69.48, '05 · WHAT THE REPORT SAYS'),
 (69.48, 94.0, '06 · HUMAN REVIEW'),
]

def clamp(x,a=0.0,b=1.0): return max(a,min(b,x))
def ease(x):
    x=clamp(x); return x*x*(3-2*x)
def pop(t, delay=0.0, dur=.55): return ease((t-delay)/dur)
def rgba(hexcolor, alpha=255):
    h=hexcolor.lstrip('#'); return tuple(int(h[i:i+2],16) for i in (0,2,4))+(int(alpha),)
def blend(a,b,t): return tuple(round(x+(y-x)*clamp(t)) for x,y in zip(a,b))
def text_width(draw, txt, font): return draw.textbbox((0,0),txt,font=font)[2]
def wrap(draw, text, font, maxw):
    words=text.split(); lines=[]; line=''
    for word in words:
        test=(line+' '+word).strip()
        if line and text_width(draw,test,font)>maxw:
            lines.append(line); line=word
        else: line=test
    if line: lines.append(line)
    return lines

def rounded(draw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(tuple(map(int,box)),radius=radius,fill=fill,outline=outline,width=width)

def draw_lines(draw, x,y, lines,font, fill, gap=6, max_width=None):
    yy=y
    for line in lines:
        draw.text((x,yy),line,font=font,fill=fill)
        bb=draw.textbbox((x,yy),line,font=font); yy=bb[3]+gap
    return yy

def draw_wrapped(draw,x,y,text,font,fill,maxw,gap=6):
    return draw_lines(draw,x,y,wrap(draw,text,font,maxw),font,fill,gap,maxw)

def arrow(draw, p0, p1, color, width=3, progress=1.0, dash=False):
    x0,y0=p0; x1,y1=p1; end=(x0+(x1-x0)*clamp(progress), y0+(y1-y0)*clamp(progress))
    if dash:
        length=math.hypot(end[0]-x0,end[1]-y0); n=max(1,int(length/11))
        for i in range(0,n,2):
            a=i/n; b=min(i+1,n)/n
            draw.line((x0+(end[0]-x0)*a,y0+(end[1]-y0)*a,x0+(end[0]-x0)*b,y0+(end[1]-y0)*b),fill=color,width=width)
    else: draw.line((x0,y0,*end),fill=color,width=width)
    if progress>=.94:
        ang=math.atan2(y1-y0,x1-x0); size=12
        for da in (2.55,-2.55):
            q=(x1+size*math.cos(ang+da),y1+size*math.sin(ang+da)); draw.line((x1,y1,*q),fill=color,width=width)

def mark(draw,x,y,s=1.0):
    rounded(draw,(x,y,x+46*s,y+46*s),14*s,C['ink'])
    pts=[(x+12*s,y+30*s),(x+22*s,y+12*s),(x+35*s,y+33*s)]
    draw.line(pts,fill=C['lime'],width=max(2,int(2*s)),joint='curve')
    draw.line((x+12*s,y+30*s,x+36*s,y+30*s),fill=C['lime'],width=max(2,int(2*s)))
    for (px,py),co in zip(pts,[C['mint'],C['coral'],C['violet']]): draw.ellipse((px-3*s,py-3*s,px+3*s,py+3*s),fill=co)

def background(t):
    im=Image.new('RGB',(W,H),C['paper']); d=ImageDraw.Draw(im,'RGBA')
    # Very subtle paper grain and slow parallax dot field.
    ox=int((t*3)%32); oy=int((t*1.5)%32)
    for y in range(20+oy,H,32):
        for x in range(18+ox,W,32): d.ellipse((x,y,x+1.5,y+1.5),fill=(100,110,100,28))
    d.ellipse((1020,-170,1390,200),fill=(151,135,255,18))
    d.ellipse((-150,540,190,880),fill=(89,215,190,20))
    return im

def shell(t, scene_idx, caption=''):
    im=background(t); d=ImageDraw.Draw(im,'RGBA')
    # Compact project identity and chapter marker.
    mark(d,44,30,.78)
    d.text((84,34),'BIO-AUDIT',font=FONT['monobold'],fill=C['ink'])
    d.text((84,55),'STATIC ANALYSIS · EVIDENCE-LINKED REVIEW',font=FONT['tiny'],fill=C['muted'])
    label=SCENES[scene_idx][2]
    d.rounded_rectangle((1015,34,1237,67),radius=9,fill=rgba(C['ink']))
    d.text((1030,44),label,font=FONT['monosmall'],fill=rgba(C['white']))
    # Progress track.
    d.rounded_rectangle((42,694,1238,699),radius=3,fill=rgba(C['line']))
    progress=clamp(t/DURATION)
    d.rounded_rectangle((42,694,42+1196*progress,699),radius=3,fill=rgba(C['lime']))
    # Accurate sentence captions, timed from word-level transcription.
    if caption:
        rounded(d,(66,609,1214,676),15,rgba(C['ink'],238))
        d.rounded_rectangle((66,609,73,676),radius=3,fill=rgba(C['mint']))
        lines=wrap(d,caption,FONT['caption'],1082)
        if len(lines)>2: lines=[lines[0],lines[1][:max(0,len(lines[1])-1)]+'…']
        h=24*len(lines)+4*(len(lines)-1); y=609+(67-h)//2
        draw_lines(d,94,y,lines,FONT['caption'],rgba(C['white']),4)
    return im

def paper_icon(draw,x,y):
    rounded(draw,(x,y,x+42,y+52),5,rgba(C['white']),rgba(C['ink']),2)
    draw.polygon([(x+28,y),(x+42,y+14),(x+28,y+14)],fill=rgba('#E8E7DD'))
    for i,w in enumerate((27,23,29,18)):
        draw.line((x+8,y+22+i*7,x+8+w,y+22+i*7),fill=rgba(C['muted']),width=2)

def draw_scene0(im,t,st):
    d=ImageDraw.Draw(im,'RGBA'); a=pop(st,0,.8)
    d.text((70,116),'THE CHALLENGE',font=FONT['monobold'],fill=rgba(C['green'],int(255*a)))
    draw_lines(d,70,153,['What a paper says.','What the code contains.'],FONT['h1'],rgba(C['ink'],int(255*a)),2)
    d.text((72,267),'The comparison can be slow — and easy to miss.',font=FONT['body'],fill=rgba(C['muted'],int(255*a)))
    # Paper card enters from left.
    q=pop(st,.55,.8); px=72-250*(1-q); py=371
    rounded(d,(px,py,px+445,py+185),18,rgba(C['white'],int(255*q)),rgba(C['ink'],int(255*q)),2)
    d.text((px+24,py+19),'MANUSCRIPT · METHODS',font=FONT['monosmall'],fill=rgba(C['muted'],int(255*q)))
    draw_wrapped(d,px+24,py+61,'“Reads are processed in packs of 1000.”',FONT['serif'],rgba(C['ink'],int(255*q)),385,9)
    d.rounded_rectangle((px+24,py+139,px+148,py+166),radius=6,fill=rgba('#F4F7E2',int(255*q)))
    d.text((px+36,py+146),'CLAIM  ·  01',font=FONT['monosmall'],fill=rgba(C['green'],int(255*q)))
    # Code card enters from right.
    q2=pop(st,.85,.8); cx=765+260*(1-q2); cy=371
    rounded(d,(cx,cy,cx+445,cy+185),18,rgba(C['dark2'],int(255*q2)),rgba(C['ink'],int(255*q2)),2)
    d.text((cx+22,cy+20),'REPOSITORY · C++',font=FONT['monosmall'],fill=rgba('#B9C5BE',int(255*q2)))
    d.text((cx+22,cy+68),'#define PACK_SIZE',font=FONT['mono'],fill=rgba(C['white'],int(255*q2)))
    # Highlight arrives exactly as the evidence trail travels.
    hl=pop(st,1.55,.55)
    rounded(d,(cx+225,cy+60,cx+309,cy+102),8,rgba(C['lime'],int(240*hl)))
    d.text((cx+242,cy+68),'1000',font=FONT['h3'],fill=rgba(C['ink'],int(255*hl)))
    d.text((cx+22,cy+128),'options.cpp  ·  line 3',font=FONT['monosmall'],fill=rgba('#B9C5BE',int(255*q2)))
    # Search lens / connecting evidence trail.
    prog=pop(st,1.1,1.0); x0=520; x1=755
    d.line((x0,464,x0+(x1-x0)*prog,464),fill=rgba(C['green'],240),width=4)
    if prog<1:
        x=x0+(x1-x0)*prog; d.ellipse((x-7,457,x+7,471),fill=rgba(C['coral']))
    else:
        d.polygon([(x1,456),(x1+14,464),(x1,472)],fill=rgba(C['green']))
        d.ellipse((620,427,680,487),outline=rgba(C['coral']),width=5)
        d.line((670,478,690,497),fill=rgba(C['coral']),width=6)
    return im

def draw_scene1(im,t,st):
    d=ImageDraw.Draw(im,'RGBA'); a=pop(st,0,.7)
    d.text((70,114),'ONE PAPER. ONE CODEBASE.',font=FONT['monobold'],fill=rgba(C['green'],int(255*a)))
    draw_lines(d,70,150,['Start with the sources','you already have.'],FONT['h1'],rgba(C['ink'],int(255*a)),3)
    d.text((72,263),'Choose the paper, then bring in the repository.',font=FONT['body'],fill=rgba(C['muted'],int(255*a)))
    q=pop(st,.4,.65)
    # Left document card
    x=92-140*(1-q); y=343
    rounded(d,(x,y,x+470,y+207),18,rgba(C['white'],int(255*q)),rgba(C['ink'],int(255*q)),2)
    paper_icon(d,x+27,y+28)
    d.text((x+91,y+28),'RESEARCH PAPER',font=FONT['monobold'],fill=rgba(C['ink'],int(255*q)))
    d.text((x+91,y+59),'Selectable-text PDF or TXT',font=FONT['small'],fill=rgba(C['muted'],int(255*q)))
    rounded(d,(x+28,y+115,x+440,y+167),9,rgba('#F4F7E2',int(255*q)))
    d.text((x+46,y+130),'Paper claims  →  extracted text',font=FONT['monosmall'],fill=rgba(C['green'],int(255*q)))
    d.text((x+28,y+181),'Scanned PDF? OCR it before upload.',font=FONT['tiny'],fill=rgba(C['muted'],int(255*q)))
    # Right source choices
    q2=pop(st,.75,.65); xx=717+155*(1-q2)
    rounded(d,(xx,y,xx+470,y+207),18,rgba(C['white'],int(255*q2)),rgba(C['ink'],int(255*q2)),2)
    d.text((xx+28,y+24),'CODE REPOSITORY',font=FONT['monobold'],fill=rgba(C['ink'],int(255*q2)))
    cards=[('SOURCE FILES','.py  ·  .R  ·  .cpp'),('ZIP ARCHIVE','Repository folder'),('PUBLIC GIT','GitHub · GitLab · Bitbucket')]
    for i,(title,sub) in enumerate(cards):
        yy=y+61+i*45; amount=pop(st,.85+i*.18,.45)
        rounded(d,(xx+26,yy,xx+440,yy+37),7,rgba(C['paper'],int(255*amount)),rgba(C['line'],int(255*amount)),1)
        d.ellipse((xx+39,yy+13,xx+50,yy+24),fill=rgba([C['mint'],C['coral'],C['violet']][i],int(255*amount)))
        d.text((xx+64,yy+7),title,font=FONT['monosmall'],fill=rgba(C['ink'],int(255*amount)))
        d.text((xx+226,yy+8),sub,font=FONT['tiny'],fill=rgba(C['muted'],int(255*amount)))
    # moving connector
    p=pop(st,1.0,.8); arrow(d,(565,447),(700,447),rgba(C['green']),3,p,True)
    d.text((534,485),'TEMPORARY INTAKE',font=FONT['tiny'],fill=rgba(C['muted']))
    return im

def draw_scene2(im,t,st):
    d=ImageDraw.Draw(im,'RGBA'); a=pop(st,0,.6)
    d.text((70,113),'CLAIMS IN. CODE FACTS OUT.',font=FONT['monobold'],fill=rgba(C['green'],int(255*a)))
    d.text((70,148),'Two lightweight scans. One comparison.',font=FONT['h2'],fill=rgba(C['ink'],int(255*a)))
    # Left manuscript with phrase highlighting
    q=pop(st,.35,.65); x=68-100*(1-q); y=253
    rounded(d,(x,y,x+500,y+286),17,rgba(C['white'],int(255*q)),rgba(C['ink'],int(255*q)),2)
    d.text((x+23,y+18),'PAPER TEXT · SENTENCE 01',font=FONT['monosmall'],fill=rgba(C['muted'],int(255*q)))
    lines=['Reads are processed in','packs of 1000 and each pack','is assigned to a thread.']
    for i,line in enumerate(lines):
        yy=y+67+i*39
        d.text((x+25,yy),line,font=FONT['serif'],fill=rgba(C['ink'],int(255*q)))
    p=pop(st,1.0,.7)
    rounded(d,(x+23,y+104,x+151,y+136),7,rgba(C['lime'],int(170*p)))
    rounded(d,(x+263,y+104,x+333,y+136),7,rgba(C['lime'],int(170*p)))
    d.text((x+25,y+220),'RULE-BASED CANDIDATE CLAIM',font=FONT['monosmall'],fill=rgba(C['green'],int(255*p)))
    d.text((x+25,y+245),'number + nearby parameter language',font=FONT['tiny'],fill=rgba(C['muted'],int(255*p)))
    # right scanner source code
    q2=pop(st,.65,.7); xx=714+100*(1-q2)
    rounded(d,(xx,y,xx+500,y+286),17,rgba(C['dark2'],int(255*q2)),rgba(C['ink'],int(255*q2)),2)
    d.text((xx+23,y+18),'REPOSITORY SCAN · C++',font=FONT['monosmall'],fill=rgba('#C0CCC4',int(255*q2)))
    code=[('#include <thread>', '#9EB1A7'),('#define PACK_SIZE 1000',C['white']),('int thread = 3;',C['white']),('int qualified_quality_phred = 15;',C['white'])]
    scan=pop(st,1.25,.8)
    for i,(line,color) in enumerate(code):
        yy=y+67+i*42
        if i==1: rounded(d,(xx+16,yy-5,xx+475,yy+29),7,rgba(C['green'],int(115*scan)))
        d.text((xx+21,yy),f'{i+1:02d}',font=FONT['monosmall'],fill=rgba('#87938C',int(255*q2)))
        d.text((xx+58,yy),line,font=FONT['mono'],fill=rgba(color,int(255*q2)))
    d.text((xx+22,y+245),'VALUES  ·  NAMES  ·  CALLS  ·  IMPORTS  ·  LINES',font=FONT['monosmall'],fill=rgba(C['mint'],int(255*scan)))
    # bridge
    p=pop(st,1.55,.7); arrow(d,(570,398),(695,398),rgba(C['green']),3,p,True)
    rounded(d,(508,333,756,373),18,rgba(C['paper'],int(255*p)),rgba(C['green'],int(230*p)),1)
    d.text((529,344),'NO CODE EXECUTION',font=FONT['monosmall'],fill=rgba(C['green'],int(255*p)))
    return im

def draw_scene3(im,t,st):
    d=ImageDraw.Draw(im,'RGBA'); a=pop(st,0,.55)
    d.text((70,111),'FROM WORDS TO EVIDENCE',font=FONT['monobold'],fill=rgba(C['green'],int(255*a)))
    d.text((70,146),'Does the value belong to this setting?',font=FONT['h2'],fill=rgba(C['ink'],int(255*a)))
    # claim and code identifiers
    q=pop(st,.25,.6)
    rounded(d,(76,238,558,370),16,rgba(C['white'],int(255*q)),rgba(C['ink'],int(255*q)),2)
    d.text((98,258),'PAPER CLAIM',font=FONT['monosmall'],fill=rgba(C['muted'],int(255*q)))
    d.text((98,300),'“packs of 1000”',font=FONT['serif'],fill=rgba(C['ink'],int(255*q)))
    rounded(d,(722,238,1204,370),16,rgba(C['dark2'],int(255*q)),rgba(C['ink'],int(255*q)),2)
    d.text((746,258),'CODE FACT',font=FONT['monosmall'],fill=rgba('#B8C4BD',int(255*q)))
    d.text((746,300),'PACK_SIZE  =  1000',font=FONT['monobold'],fill=rgba(C['white'],int(255*q)))
    # word/name linking lines
    p=pop(st,.75,.9)
    d.line((220,338,330,414,476,414,536,338),fill=rgba(C['green'],int(235*p)),width=3)
    d.line((788,338,900,414,1052,414,1120,338),fill=rgba(C['green'],int(235*p)),width=3)
    for cx,label in ((274,'PACKS'),(1000,'PACK_SIZE')):
        rounded(d,(cx-71,398,cx+71,433),16,rgba(C['palegreen'],int(255*p)),rgba(C['green'],int(255*p)),1)
        bb=d.textbbox((0,0),label,font=FONT['monosmall']); tw=bb[2]
        d.text((cx-tw/2,408),label,font=FONT['monosmall'],fill=rgba(C['green'],int(255*p)))
    # central equal value token
    v=pop(st,1.0,.6)
    d.ellipse((595,378,685,468),fill=rgba(C['lime'],int(255*v)),outline=rgba(C['ink'],int(255*v)),width=2)
    d.text((613,402),'1000',font=FONT['h3'],fill=rgba(C['ink'],int(255*v)))
    # result card
    r=pop(st,1.7,.65)
    rounded(d,(398,502,882,577),18,rgba(C['ink'],int(255*r)),rgba(C['ink'],int(255*r)),2)
    d.ellipse((422,524,450,552),fill=rgba(C['lime'],int(255*r)))
    d.text((429,526),'✓',font=FONT['bodybold'],fill=rgba(C['ink'],int(255*r)))
    d.text((468,518),'MATCH',font=FONT['h3'],fill=rgba(C['lime'],int(255*r)))
    d.text((468,551),'related name + same value',font=FONT['small'],fill=rgba(C['white'],int(255*r)))
    # evidence trail dot animates from code to result
    dot=pop(st,1.4,.6); dx=750; dy=370+(500-370)*dot
    d.ellipse((dx-6,dy-6,dx+6,dy+6),fill=rgba(C['coral']))
    return im

def verdict_card(d,x,y,w,label,sub,color,prog):
    h=63; xx=x+24*(1-prog); alpha=int(255*prog)
    rounded(d,(xx,y,xx+w,y+h),13,rgba(C['white'],alpha),rgba(C['line'],alpha),1)
    d.rounded_rectangle((xx,y,xx+7,y+h),radius=4,fill=rgba(color,alpha))
    d.text((xx+19,y+9),label,font=FONT['monobold'],fill=rgba(C['ink'],alpha))
    d.text((xx+19,y+34),sub,font=FONT['tiny'],fill=rgba(C['muted'],alpha))

def draw_scene4(im,t,st):
    d=ImageDraw.Draw(im,'RGBA'); a=pop(st,0,.6)
    d.text((70,111),'A FINDING IS NOT A GUESS',font=FONT['monobold'],fill=rgba(C['green'],int(255*a)))
    d.text((70,146),'The report shows what it found — and where.',font=FONT['h2'],fill=rgba(C['ink'],int(255*a)))
    # verdict examples left
    verdict_card(d,75,247,525,'MATCH','Related parameter name · same value',C['green'],pop(st,.3,.55))
    verdict_card(d,75,321,525,'MISMATCH','Related parameter · different value',C['coral'],pop(st,.55,.55))
    verdict_card(d,75,395,525,'CALL FOUND','Recognized function call is present',C['mint'],pop(st,.8,.55))
    verdict_card(d,75,469,525,'IMPORT ONLY','Package imported · no call located',C['violet'],pop(st,1.05,.55))
    # result detail panel
    p=pop(st,.6,.7); x=690+100*(1-p); y=247
    rounded(d,(x,y,x+515,y+303),18,rgba(C['dark2'],int(255*p)),rgba(C['ink'],int(255*p)),2)
    d.text((x+23,y+20),'FINDING DETAIL',font=FONT['monosmall'],fill=rgba('#C1CCC5',int(255*p)))
    d.text((x+23,y+61),'MATCH',font=FONT['h3'],fill=rgba(C['lime'],int(255*p)))
    d.text((x+23,y+106),'Paper parameter / result',font=FONT['tiny'],fill=rgba('#B3BFB8',int(255*p)))
    rounded(d,(x+22,y+132,x+490,y+202),10,rgba('#1A242A',int(255*p)),rgba('#52615A',int(255*p)),1)
    d.text((x+39,y+145),'options.cpp   ·   line 3',font=FONT['monosmall'],fill=rgba(C['mint'],int(255*p)))
    d.text((x+39,y+172),'#define PACK_SIZE 1000',font=FONT['mono'],fill=rgba(C['white'],int(255*p)))
    d.text((x+23,y+228),'Inspect · search · filter · export',font=FONT['small'],fill=rgba(C['white'],int(255*p)))
    d.text((x+23,y+264),'JSON   /   PORTABLE HTML',font=FONT['monosmall'],fill=rgba(C['mint'],int(255*p)))
    return im

def draw_scene5(im,t,st):
    d=ImageDraw.Draw(im,'RGBA'); a=pop(st,0,.55)
    d.text((70,108),'STATIC EVIDENCE. HUMAN JUDGMENT.',font=FONT['monobold'],fill=rgba(C['green'],int(255*a)))
    d.text((70,143),'Clear signals. Honest limits.',font=FONT['h2'],fill=rgba(C['ink'],int(255*a)))
    # Orange runtime result card
    p=pop(st,.25,.65)
    rounded(d,(72,224,1208,359),20,rgba(C['palecoral'],int(255*p)),rgba(C['coral'],int(255*p)),2)
    d.ellipse((98,252,151,305),fill=rgba(C['coral'],int(255*p)))
    # stopwatch icon
    d.ellipse((112,266,138,292),outline=rgba(C['ink'],int(255*p)),width=2)
    d.line((125,272,125,280,132,284),fill=rgba(C['ink'],int(255*p)),width=2)
    d.text((174,245),'“2.7× faster than the baseline”',font=FONT['serif'],fill=rgba(C['ink'],int(255*p)))
    d.text((174,291),'RESULT NEEDS RUN',font=FONT['monobold'],fill=rgba('#8A4B37',int(255*p)))
    d.text((646,259),'Static inspection cannot verify speed.',font=FONT['bodybold'],fill=rgba(C['ink'],int(255*p)))
    d.text((646,295),'A benchmark on the right data is needed.',font=FONT['small'],fill=rgba(C['muted'],int(255*p)))
    # Three limitation cards
    limits=[('NOT PROOF','A match does not prove correct execution.',C['mint']),('NOT ABSENCE','Missing evidence may be outside the scan.',C['violet']),('NOT A BENCHMARK','Runtime and reproducibility need review.',C['lime'])]
    for i,(title,body,color) in enumerate(limits):
        x=72+i*382; q=pop(st,.65+i*.2,.6); xx=x+24*(1-q)
        rounded(d,(xx,401,xx+354,526),16,rgba(C['white'],int(255*q)),rgba(C['ink'],int(255*q)),1)
        rounded(d,(xx+17,418,xx+29,430),5,rgba(color,int(255*q)))
        d.text((xx+40,416),title,font=FONT['monobold'],fill=rgba(C['ink'],int(255*q)))
        draw_wrapped(d,xx+18,456,body,FONT['small'],rgba(C['muted'],int(255*q)),315,4)
    # final mark / tagline settle
    end=pop(st,1.5,.8)
    mark(d,468,551,.84)
    d.text((514,557),'BIO-AUDIT',font=FONT['h3'],fill=rgba(C['ink'],int(255*end)))
    d.text((700,565),'A clearer trail from claim to evidence.',font=FONT['small'],fill=rgba(C['muted'],int(255*end)))
    return im

SCENE_FN=[draw_scene0,draw_scene1,draw_scene2,draw_scene3,draw_scene4,draw_scene5]

def caption_for(segments,t):
    for seg in segments:
        if seg['start'] <= t < seg['end']:
            return seg['text']
    return ''

def scene_at(t):
    for i,(a,b,_) in enumerate(SCENES):
        if a <= t < b or (i==len(SCENES)-1 and t<=b): return i,a,b
    return len(SCENES)-1,SCENES[-1][0],SCENES[-1][1]

def make_frame(t,segments):
    idx,start,end=scene_at(t)
    im=shell(t,idx,caption_for(segments,t))
    SCENE_FN[idx](im,t-start,t)
    # Crossfade only at boundaries, retaining caption timing from original narration.
    xfade=.42
    if idx < len(SCENES)-1 and t > end-xfade:
        amount=ease((t-(end-xfade))/xfade)
        nxt=shell(t,idx+1,caption_for(segments,t))
        SCENE_FN[idx+1](nxt,0,t)
        im=Image.blend(im,nxt,amount)
    # Brief fade-in and final smooth resolve.
    if t < .45: im=Image.blend(background(t),im,ease(t/.45))
    if t > DURATION-.7: im=Image.blend(im,background(t),ease((t-(DURATION-.7))/.7)*.42)
    return im

def srt_time(seconds):
    ms=round(seconds*1000); h,ms=divmod(ms,3600000); m,ms=divmod(ms,60000); s,ms=divmod(ms,1000)
    return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'

def write_srt(segments):
    parts=[]
    for n,seg in enumerate(segments,1):
        txt='\n'.join(wrap(ImageDraw.Draw(Image.new('RGB',(1,1))),seg['text'],FONT['caption'],48))
        parts.append(f"{n}\n{srt_time(seg['start'])} --> {srt_time(seg['end'])}\n{txt}")
    SRT.write_text('\n\n'.join(parts)+'\n',encoding='utf-8')

def main():
    if not VOICE.exists() or not MUSIC.exists() or not TRANSCRIPT.exists():
        raise SystemExit('Missing narration, music, or transcription input.')
    segments=json.loads(TRANSCRIPT.read_text(encoding='utf-8'))['segments']
    write_srt(segments)
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',str(VOICE),'-stream_loop','-1','-i',str(MUSIC),
         '-filter_complex',
         '[1:a]aformat=sample_rates=48000:channel_layouts=stereo,volume=0.82[voice];'
         '[2:a]aformat=sample_rates=48000:channel_layouts=stereo,volume=0.045,afade=t=in:st=0:d=2,afade=t=out:st=91:d=3[bed];'
         '[voice][bed]amix=inputs=2:duration=longest:dropout_transition=0,atrim=0:94,alimiter=limit=0.88[aout]',
         '-map','0:v:0','-map','[aout]','-t',str(DURATION),'-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-r',str(FPS),'-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',str(OUTPUT)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    total=round(DURATION*FPS)
    try:
        for n in range(total):
            t=n/FPS
            frame=make_frame(t,segments)
            proc.stdin.write(frame.tobytes())
            if n%240==0: print(f'Rendered {n}/{total} frames ({t:.1f}s)',flush=True)
        proc.stdin.close()
        code=proc.wait()
        if code: raise SystemExit(f'ffmpeg render failed with exit code {code}')
    except BaseException:
        try: proc.stdin.close()
        except Exception: pass
        proc.terminate(); proc.wait(); raise
    print(f'Wrote {OUTPUT} and {SRT}',flush=True)

if __name__=='__main__': main()
