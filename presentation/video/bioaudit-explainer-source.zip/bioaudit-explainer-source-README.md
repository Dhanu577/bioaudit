# Bio-Audit Explainer — Source Bundle

This bundle contains the motion-graphics renderer and the local media assets used to create the narrated explainer.

## Included

- `bioaudit_explainer.py` — Python/Pillow animation renderer
- `bioaudit-explainer-voiceover.wav` — standalone narration
- `bioaudit-explainer-music.mp3` — generated instrumental underscore
- `bioaudit-explainer-transcription.json` — word-timed narration transcript used to place captions
- `bioaudit-explainer-captions.srt` — subtitle file

## Render

Install Python 3, Pillow, and FFmpeg with H.264/AAC support. Keep the files together, then run:

```bash
python3 bioaudit_explainer.py
```

The script writes `bioaudit-explainer.mp4` beside itself. It renders a 94-second 1280×720 video at 24 fps with H.264 video, 48 kHz stereo AAC narration/music, and burned-in captions.

The visuals use vector-style motion graphics. The displayed `PACK_SIZE = 1000` C++ example reflects the included Bio-Audit validation fixture. The video describes the analyzer as static inspection; it does not imply that audited repository code is executed.
